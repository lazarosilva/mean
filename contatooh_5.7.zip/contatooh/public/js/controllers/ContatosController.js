angular.module('contatooh').controller('ContatosController', function($scope, $resource){
    $scope.contatos = [];
    $scope.filtro = '';
    var Contato = $resource('/contatos');
    
    function buscaContatos(){
        Contato.query(function(contatos){
            $scope.contatos = contatos;
        },
        function(erro){
            console.log("Não foi possível obter a lista de contatos");
            console.log(erro);
        });
    }

    buscaContatos();
    /*$http({
        method: 'GET',
        url: '/contatos'
    }).then(function(data){
        $scope.contatos = data;
    }, function(statusText){
        console.log("Não foi possível obter a lista de contatos");
        console.log(statusText);
    });

    console.log($scope.contatos)*/
    // $http.get('/contatos').success(function(data){
    //     $scope.contatos = data;
    // }).error(function(statusText){
    //     console.log("Não foi possível obter a lista de contatos");
    //     console.log(statusText);
    // });
});
var contatos = [
    {_id:1, nome: 'contato1', email:'cont1@contatooh.com.br'},
    {_id:2, nome: 'contato2', email:'cont2@contatooh.com.br'},
    {_id:3, nome: 'contato3', email:'cont3@contatooh.com.br'}
];

module.exports.listaContatos = function(application, req, res){
    res.json(contatos);
}

module.exports.obtemContato = function(application, req, res){
    var idContato = req.params.id;
    var contato = contatos.filter(function(contato){
        return contato._id == idContato;
    })[0];
    contato ? res.json(contato) : res.status(404).send('Contato inexistente!');
}
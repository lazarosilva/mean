angular.module('contatooh').controller('ContatosController', function($scope, Contato){
    $scope.contatos = [];
    $scope.filtro = '';
    //var Contato = $resource('/contatos/:id');


    function buscaContatos(){
        Contato.query(function(contatos){
            $scope.contatos = contatos;
        },
        function(erro){
            console.log("Não foi possível obter a lista de contatos");
            console.log(erro);
        });
    }
    buscaContatos();
 
    //não está atualizando a lista de contatos dinamicamente 
    $scope.remove = function(contato){ 
            Contato.delete(
            {id: contato._id}, 
            buscaContatos, 
            function(erro){
                console.log('Não foi possível remover o contato');
                console.log(erro);
        });
    };

    // $scope.apaga = function(contato){
    //     Contato.delete({id: contato._id}).then(function(){
    //         console.log('Excluído com sucesso');
    //         buscaContatos();
    //     }).catch(function(erro){
    //         console.log('Não foi possível salvar.');
    //         console.log(erro);
    //     });
    // };

    
    /*$http({
        method: 'GET',
        url: '/contatos'
    }).then(function(data){
        $scope.contatos = data;
    }, function(statusText){
        console.log("Não foi possível obter a lista de contatos");
        console.log(statusText);
    });

    console.log($scope.contatos)*/
    // $http.get('/contatos').success(function(data){
    //     $scope.contatos = data;
    // }).error(function(statusText){
    //     console.log("Não foi possível obter a lista de contatos");
    //     console.log(statusText);
    // });
});
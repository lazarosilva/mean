var express = require('express');
var consign = require('consign');
var bodyparser = require('body-parser');

var app = express();
app.set('view engine', 'ejs');
app.set('views', './app/views');
app.use(express.static('./public'))
app.use(bodyparser.urlencoded({extended: true}));
app.use(bodyparser.json());
app.use(require('method-override')());

consign()
    .include('app/routes')
    .then('app/models')
    .then('app/controllers')
    .into(app);

app.listen(3000, function(){
    console.log('APP rodando na porta 3000');
});
